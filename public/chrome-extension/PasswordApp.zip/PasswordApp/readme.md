##

* [API Reference](https://developer.chrome.com/docs/extensions/reference/)
* [Manifest format](https://developer.chrome.com/docs/extensions/mv3/manifest/)
  
##Crypt
* [SubtleCrypto](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto)
* [blowfish lib](https://github.com/egoroof/blowfish)
* [pem to key](https://riptutorial.com/javascript/example/17846/converting-pem-key-pair-to-cryptokey)
* [algo](https://qna.habr.com/q/49850)

##

* [Папка расширений](C:\Users\Umberto\AppData\Local\Google\Chrome\User Data\Default\Extensions)